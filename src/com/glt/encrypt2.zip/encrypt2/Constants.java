package com.glt.encrypt2;

/**
 * Description
 * <p>
 * </p>
 * DATE 2020/1/15.
 *
 * @author genglintong.
 */
public class Constants {
    public static final String QUERY_PARAM_ACCESS_KEY_ID = "accessKeyId";

    public static final String QUERY_PARAM_ALGORITHM = "algorithm";

    public static final String QUERY_PARAM_NONCE = "nonce";

    public static final String QUERY_PARAM_TIMESTAMP = "timestamp";

    public static final String QUERY_PARAM_SIGN = "sign";
}
